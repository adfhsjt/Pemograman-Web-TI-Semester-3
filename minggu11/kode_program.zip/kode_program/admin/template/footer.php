<script src="assets/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.3.2/dist/chart.umd.js" integrity="sha384-eI7PSr3L1XLISH8JdDII5YN/
njoSsxfbrkCTnJrzXt+ENP5M0VBxD+16sEG4zoLp" crossorigin="anonymous"></script>
<script src="assets/custom/dashboard.js"></script>
</body>

</html>